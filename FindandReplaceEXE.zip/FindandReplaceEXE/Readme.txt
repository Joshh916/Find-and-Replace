This program finds text in one or more text based documents and replacesit with another.


If you have a text based document under multiple user folders (Example 1: C:\Users\Gene\filename.txt, and C:\Users\Tina\filename.txt) then you would want to check the first text box and enter filename.txt in the field available (also works on subdirectories, Example 2: "C:\Users\Gene\Documents\Filename.txt" you would type in "Documents\Filename.txt").

To change the text on a single user or location (Example 3: "C:\Windows\Filename.txt") leave the Checkboxes empty and enter the file Path into the field available.

To change multiple filesat once, separate each path with a comma and no spaces (Example 4: "C:\Filename.txt,C:\Windows\Filename2.txt")

To change Files in both user folders, and other locations, as in examples 1 and 3, Check the second Checkbox and fill in both fields.

The "Find" Field is where you type in the text you re looking for, and the "Replace" Field is where you type in the text you are going to replace it with.

This is a free program, I wrote this program to provide a tool to people who need it and I am not responsible for what you do with it. Use at your own risk, changeing configuration files without proper knowlege could damage your system.

Press the "Save" to save the text in each field, the next time the program is opened the text will be automatically restored. 

If you have and questions, or comments feel free to reach out to me at joshh916@gmail.com
